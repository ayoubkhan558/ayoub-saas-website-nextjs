import Link from "next/link";
import type { PortfolioData } from "@/context/PortfolioContentContext";
import { IconGlyph } from "./IconGlyph";
import styles from "./ServicesSection.module.scss";

type Service = PortfolioData["services"][number];

export function ServicesSection({ services }: { services: Service[] }) {
  const serviceHref = (href: string) => (href === "#cta" ? "/contact" : href);

  return (
    <section className="section" id="services">
      <div className="section__inner">
        <div className={`container ${styles["services"]}`}>
          <header className="section-header section-header--center">
            <span className="section-header__label">Productized solutions</span>
            <h2 className="section-header__title">
              What you can hire me for
            </h2>
            <p className="section-header__text">
              Business problems first, implementation details second. Pick the outcome you need and I will choose the right build path.
            </p>
          </header>
          <div className={styles["services__grid"]}>
            {services.map((service, index) => (
              <article
                className={`${styles["services__card"]} ${service.featured ? styles["services__card--featured"] : ""}`}
                key={service.name}
              >
                <div className={styles["services__icon"]}>
                  <IconGlyph name={index === 0 ? "globe" : index === 1 ? "cart" : "code"} />
                  <span className={styles["services__index"]}>0{index + 1}</span>
                </div>
                <h3 className={styles["services__card-title"]}>{service.name}</h3>
                <p className={styles["services__card-text"]}>{service.description}</p>
                <strong className={styles["services__price"]}>{service.price}</strong>
                <a className={styles["services__link"]} href={serviceHref(service.href)} title={`${service.cta} with Muhammad Ayoub`}>
                  {service.cta}
                  <IconGlyph name="arrowRight" />
                </a>
              </article>
            ))}
          </div>
          <div className={styles["services__actions"]}>
            <Link className="button button--light" href="/services" title="View all website development services">
              View all services
              <IconGlyph name="arrowRight" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
